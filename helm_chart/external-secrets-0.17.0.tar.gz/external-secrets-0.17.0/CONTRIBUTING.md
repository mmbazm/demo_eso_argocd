# Contributing

See the [Developer guide](docs/contributing/devguide.md) for information
about setting up your development environment, and the
[Contributing Process](docs/contributing/process.md) document
for details about the workflow.
