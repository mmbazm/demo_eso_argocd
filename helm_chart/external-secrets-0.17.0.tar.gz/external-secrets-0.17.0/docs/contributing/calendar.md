# Community meetings - CNCF calendar

ESO community calls can be subscribed to from the CNCF Project Calendar page here [CNCF Calendar](https://www.cncf.io/calendar/).

Look for the event called `External Secrets Bi-weekly community meeting`.
