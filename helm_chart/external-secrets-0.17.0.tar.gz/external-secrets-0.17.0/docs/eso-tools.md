# ESO Tools

This page lists tools that are useful for working with External Secrets Operator. help you work with External Secrets Operator better.

## [secret2es](https://github.com/Sn0rt/secret2es)

This tool allows administrators to migrate secrets originally created by argocd-vault-plugin to external-secrets ES object.
